//
//  SampleSDK.h
//  SampleSDK
//
//  Created by HEXA-Yuheng.Chook on 21/01/2025.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleSDK.
FOUNDATION_EXPORT double SampleSDKVersionNumber;

//! Project version string for SampleSDK.
FOUNDATION_EXPORT const unsigned char SampleSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleSDK/PublicHeader.h>


